/* ---------------------------------------------------------- 
%   (C)1993 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
%   (C)1996, 1997, 1998, 1999 Japan Information Processing Development Center
%       (Read COPYRIGHT-JIPDEC for detailed information.)
----------------------------------------------------------- */

struct prioqrec
*more_priorec();

extern module topsucceed();
extern struct goalrec * enqueue_goal();
extern struct goalrec * get_top_priority_queue();
void put_top_priority_queue();

