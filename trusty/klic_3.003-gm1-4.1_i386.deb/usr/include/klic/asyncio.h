/* ---------------------------------------------------------- 
%   (C)1994, 1995 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
%   (C)1996, 1997, 1998, 1999 Japan Information Processing Development Center
%       (Read COPYRIGHT-JIPDEC for detailed information.)
----------------------------------------------------------- */
enum sigiotype {
  KLIC_SIGIO_NONE,
  KLIC_SIGIO_IN,
  KLIC_SIGIO_OUT,
  KLIC_SIGIO_INOUT
};
