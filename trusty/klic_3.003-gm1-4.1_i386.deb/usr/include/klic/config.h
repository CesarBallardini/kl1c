/*
  Copyright 1994, 1995 Institute for New Generation Computer Technology
  Read COPYRIGHT for detailed information

  Copyright 1996, 1997, 1998 Japan Information Processing Development Center
  Read COPYRIGHT-JIPDEC for detailed information

  KLIC System Configuration Setting
  This file was created by KLIC configuration script.
  Date of Confuguration: Sun Oct 18 22:18:23 UTC 2020
  Configured by: vagrant
*/

/* CPU name for locking shared-memory parallel */

#define Unknown_cpu

/* Directories for installation */

#define KLICBIN "/usr/bin"
#define KLICLIB "/usr/lib"
#define KLICINCLUDE "/usr/include"
#define KLIC_COMPILER "/usr/lib/klic/kl1cmp"
#define KLIC_DBMAKER "/usr/lib/klic/klicdb"

/* Laguage and program processing systems */

#define CC "gcc"
#define LD "gcc"
#define RANLIB "ranlib"

/* Additional CC flags for optimized compilation of KL1 programs */

#define UOPTFLAGS "-fomit-frame-pointer"

/* Additional flags for LD */

#define LIBRARIES "-lklic -L/usr/lib/i386-linux-gnu/ -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define LIBRARIES_T "-lklict -L/usr/lib/i386-linux-gnu/ -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define LIBRARIES_D "-lklicd -L/usr/lib/i386-linux-gnu/ -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define LIBRARIES_S "-lklics -L/usr/lib/i386-linux-gnu/ -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define KLIC_CC_OPTIONS ""
#define KLIC_LD_OPTIONS ""

/* Usual C macros depending on availability */

#define ASYNCIO
#define STRINGH
#undef STDDEFH
#define SETLINEBUF
#define USELOCKF
#define USESIG
#define GETRUSAGE
#define USEBCMP
#undef USEBCOPY
#define USEBZERO
#define USESTRCHR
#define USEUSLEEP
#define USEULIMIT
#define USEGETDTABLESIZE
#define USETIMER
#define NRAND48
#define ISASTREAM
#undef USESTREAMINCLUDEDIR
#undef USEPROCBIND
#undef USESELECT
#define XTERM "/usr/bin/x-terminal-emulator"
#undef DECL_SYS_ERRLIST
#undef DECL_FPRINTF

#ifdef USEBCMP
#define BCMP(x,y,len)		bcmp(x,y,len)
#else
#define BCMP(x,y,len)		memcmp(x,y,len)
#endif

#ifdef USEBCOPY
#define BCOPY(from,to,len)	bcopy(from,to,len)
#else
#define BCOPY(from,to,len)	memcpy(to,from,len)
#endif

#ifdef USEBZERO
#define BZERO(from,len)		bzero(from,len)
#else
#define BZERO(from,len)		memset(from,0,len)
#endif

#ifdef USESTRCHR
#define STRCHR			strchr
#else
#define STRCHR			index
#endif

#undef CROSS


#define DIST_COMPILER_FLAG(name, ext)     {(void)sprintf(bufp, " -DDIST -I%s -I. %s%s",     klic_incdir, (name), (ext)); }
#define DIST_LINKAGE_FLAG() 

