/* ---------------------------------------------------------- 
%   (C)1993, 1995 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
%   (C)1996, 1997, 1998, 1999 Japan Information Processing Development Center
%       (Read COPYRIGHT-JIPDEC for detailed information.)
----------------------------------------------------------- */
extern void GD_suspend();
extern void GD_make_argblock();
extern void GD_make_var();
extern void GD_make_goal_of_new();
extern void GD_make_goal_of_root();
extern void GD_make_goal_of_mehtod();
