/* ---------------------------------------------------------- 
%   (C)1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
%   (C)1996, 1997, 1998, 1999 Japan Information Processing Development Center
%       (Read COPYRIGHT-JIPDEC for detailed information.)
----------------------------------------------------------- */

extern q general_gc( /* q *term, q* allocp */ );

extern general_print( /* q *a, FILE stream, unsigned long depth,length */ );

extern struct data_object_method_table argblock_object_method_table;

extern struct predicate predicate_generic_xnew_3;
extern struct predicate predicate_generic_xroot_4;
extern struct predicate predicate_generic_xmethod_4;
